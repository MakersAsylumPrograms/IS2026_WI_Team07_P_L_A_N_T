// Plant 2: its own signal processing, touch detection and melody voice.
// Fed by the Raw2_mV / Hum2_mV fields from Plant_Stream (leaf on D35, soil on D26).
// Voice: a counter-melody one octave BELOW plant 1, same root and scale, so the two plants harmonise.
// Touch on plant 2: its voice jumps up an octave at once (stays about 1 s, then back), and the beat
// muffles exactly like a touch on plant 1.
// Reads globals from index.html: t0, SAMPLE_HZ, num(), $(), SCALES, mtof, Groove, ac, master.
"use strict";
const P2 = (() => {
  const samples = [];                       // {t, raw, plant}
  let smooth = null, base = null, prevSmooth = null, rate = 0;
  let level = 0.5, activity = 0, raw = null, lastAt = 0, noContact = false, lowCount = 0;
  let rangeLo = -5, rangeHi = 5, seen = 0;
  // touch: same detector as plant 1 (makeTouchDet in index.html)
  let boost = 0, touchAt = -1e9, releaseAt = -1e9;
  const det = makeTouchDet(
    () => { touchAt = performance.now(); if (typeof markEvent === "function") markEvent("touch2"); beatTouchSync(); update(0); },
    () => { releaseAt = performance.now(); beatTouchSync(); });
  // voice
  let oscs = [], gains = [], bus = null, deg = null, semis = null, lastNote = null, env = 1, currentHz = 0, ctx = null;

  function add(v) {
    const now = performance.now();
    if (t0 === null) return;
    const t = (now - t0) / 1000;
    raw = v; lastAt = now; seen++;
    lowCount = v < 300 ? lowCount + 1 : 0;
    noContact = lowCount > SAMPLE_HZ / 2;
    if (smooth === null) smooth = base = prevSmooth = v;
    prevSmooth = smooth;
    smooth += Math.min(1, 4 / SAMPLE_HZ) * (v - smooth);
    base += (0.02 / SAMPLE_HZ) * (smooth - base);
    const plant = smooth - base;
    rate += Math.min(1, 5 / SAMPLE_HZ) * ((smooth - prevSmooth) * SAMPLE_HZ - rate);
    samples.push({ t, raw: v, plant });
    while (samples.length && samples[0].t < t - 200) samples.shift();
    if (seen % 10 === 0 && samples.length > SAMPLE_HZ * 5) {
      const vals = [];
      for (let i = samples.length - 1; i >= 0 && samples[i].t > t - 60; i--) vals.push(samples[i].plant);
      vals.sort((a, b) => a - b);
      rangeLo = vals[Math.floor(vals.length * 0.05)]; rangeHi = vals[Math.floor(vals.length * 0.95)];
      const minSpan = num("range");
      if (rangeHi - rangeLo < minSpan) { const m = (rangeHi + rangeLo) / 2; rangeLo = m - minSpan / 2; rangeHi = m + minSpan / 2; }
    }
    level = Math.max(0, Math.min(1, (plant - rangeLo) / (rangeHi - rangeLo)));
    activity = Math.min(1, Math.abs(rate) / 8);
  }

  function touch(v) { det.feed(v); }

  function initAudio(audioCtx, dest) {
    ctx = audioCtx; oscs = []; gains = [];
    bus = ctx.createGain(); bus.gain.value = 0.9; bus.connect(dest);
    [1, 2, 3, 4].forEach(() => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; g.gain.value = 0; o.connect(g); g.connect(bus); o.start();
      oscs.push(o); gains.push(g);
    });
    deg = semis = lastNote = null;
  }
  function stopAudio() { oscs = []; gains = []; bus = null; ctx = null; }

  function update(dt) {
    const now = performance.now();
    // touch boost: instant octave up, hold 1 s after release, then back down
    const target = det.on ? 12 : (now - releaseAt < 1000 ? boost : 0);
    boost = target > boost ? target : boost + (target - boost) * (1 - Math.exp(-dt / 0.3));
    if (!ctx || !oscs.length) return;
    const fresh = now - lastAt < 500 && !noContact;
    const sc = SCALES[$("scaleSel").value] || SCALES.pentaMinor, L = sc.length, steps = L * 2 + 1;
    const pos = level * (steps - 1);
    if (deg === null || Math.abs(pos - deg) > 0.6) deg = Math.round(pos);
    const note = 12 * Math.floor(deg / L) + sc[deg % L];
    if (semis === null) semis = note;
    if (note !== lastNote) { lastNote = note; env = 0.2; }
    semis += (note - semis) * (1 - Math.exp(-Math.max(dt, 0.001) / 0.06));
    env += (1 - env) * (1 - Math.exp(-Math.max(dt, 0.001) / 0.12));
    const rootMidi = num("root") + (boost > 6 ? 12 : 0);          // one octave below plant 1's melody
    currentHz = mtof(rootMidi) * Math.pow(2, semis / 12);
    const t = ctx.currentTime, vol = num("vol2") / 100;
    const amp = [0.55, 0.18, 0.12, 0.05];                          // soft, a little hollow (odd harmonics)
    const mult = [1, 2, 3, 5];
    for (let i = 0; i < 4; i++) {
      oscs[i].frequency.setTargetAtTime(currentHz * mult[i], t, 0.03);
      gains[i].gain.setTargetAtTime(fresh ? amp[i] * env * vol * (0.7 + 0.5 * activity) : 0, t, 0.06);
    }
  }

  return {
    add, touch, initAudio, stopAudio, update, samples, humTrace: det.trace,
    get humBase() { return det.base; }, get humDelta() { return det.delta; },
    risePct() { return det.thrPct(); },
    get active() { return raw !== null && performance.now() - lastAt < 1000; },
    get raw() { return raw; }, get level() { return level; }, get hum() { return det.val; },
    get touched() { return det.on; }, get noContact() { return noContact; }, get hz() { return currentHz; },
    reset() { samples.length = 0; smooth = null; raw = null; seen = 0; det.reset(); }
  };
})();

// The beat muffles while EITHER plant is touched
function beatTouchSync() {
  if (typeof Groove === "undefined") return;
  Groove.beatTouch(!!(touchHeldKey || P2.touched));
}

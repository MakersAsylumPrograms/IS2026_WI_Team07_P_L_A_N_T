// House groove engine for the plant instrument.
// The beat (kick, clap, hats) is the fixed frame. Everything musical comes from the plant:
//   slow level (last 8 s)  -> which chord plays (changes every 2 bars)
//   level now              -> bass octave jumps, lead melody pitch, bass filter
//   activity               -> how busy the lead and hats are, brightness
//   calm for 8 bars        -> breakdown (kick and bass drop out) until the plant moves again
//   response               -> crash, big chord stab, drum fill
//   contact glitch         -> plant parts go quiet, the beat keeps going
// Reads the globals level, activity, glitching from index.html.
"use strict";
const Groove = (() => {
  let ac = null, out = null, timer = null, nextTime = 0, step = 0, bar = 0;
  let noise = null, delay = null, fb = null, delayWet = null;
  let slowLevel = 0.5, chordIdx = 0, lastLead = null, calmBars = 0, breakdown = false, fillBar = -1, crashPending = false;
  let barActivity = 0, barSteps = 0;
  const state = { chord: "", section: "intro", mood: "", lead: "-", bass: "-", variant: "" };
  // Event moods (bars left). Water = warm wash a step higher, light = brighter major mood
  const mods = { water: 0, light: 0 };
  // Touch = instant DROP: the moment the plant is touched, a kick, crash, big chord and bass hit play right away
  // in the new key, and the groove goes into an 8 bar drop. Each new touch changes something new:
  //   1st: key up a fourth   2nd: VI-VII-i-i progression   3rd: key up a fifth, double-time hats   4th: home key
  // While a hand stays on the plant: 16th-note arpeggio, 16th hats and extra stabs (it "plays" while touched).
  let touchCount = 0, buildEnd = -1, dropEnd = -1, dropShift = 0, dropProg = null, dropDouble = false, held = false;
  let beatVar = 3, holdSteps = 0, holdShift = 0, masterF = null;
  // Each drop switches the beat AND the harmony, so the change cannot blend into the groove
  const VARIANTS = ["half-time beat, key up a fourth", "breakbeat, new progression", "double-time beat, key up a fifth", "house beat, home key"];
  function touchPhase() { return bar < dropEnd ? "drop" : null; }

  // DRUMS-ONLY layer (used under the Scale melody). The melody stays the plant's voice; this is just the beat.
  // Touching the plant: the beat instantly goes muffled and half-time so the melody's octave jump stands out.
  // Letting go: the beat opens back up over one beat with a crash.
  let drumsOnly = false, beatTouched = false;
  function setDrumsOnly(on) { drumsOnly = on; }
  function setVolume(v) { if (out) out.gain.setTargetAtTime(v, ac.currentTime, 0.1); }
  function beatTouch(on) {
    if (on === beatTouched || !ac) return;
    beatTouched = on;
    const t = ac.currentTime + 0.005;
    masterF.frequency.cancelScheduledValues(t);
    if (on) masterF.frequency.setTargetAtTime(450, t, 0.02);          // muffled within about 50 ms
    else {
      masterF.frequency.setValueAtTime(450, t);
      masterF.frequency.exponentialRampToValueAtTime(20000, t + spStep() * 4);
      if (timer) crash(t);
    }
  }
  function playDrums(s, t) {
    const a = activity, intro = bar < 2;
    state.section = beatTouched ? "touched: muffled half-time" : intro ? "intro" : "groove";
    if (beatTouched) {                                   // half-time, heavy
      if (s === 0 || s === 10) kick(t);
      if (s === 8) snare(t, 0.7);
      if (s % 4 === 2) hat(t, true, 0.25);
      return;
    }
    if (!intro && s % 4 === 0) kick(t);
    if (!intro && (s === 4 || s === 12)) clap(t);
    if (s % 4 === 2) hat(t, true, 0.35 + 0.3 * a);                          // offbeat open hat
    if (!intro && s % 2 === 1 && a > 0.35) hat(t, false, 0.15 + 0.35 * a);  // busier when the plant is active
  }
  // Hand on the plant: the whole track climbs a semitone every beat (up to an octave).
  // Let go: everything falls back to the drop key with a deep bass slide and a crash.
  function touchHold(on) {
    if (on && !held) { held = true; holdSteps = 0; holdShift = 0; }
    else if (!on && held) {
      held = false;
      if (ac && timer && holdShift > 0) { const t = ac.currentTime + 0.01; bassDive(t, holdShift); crash(t); }
      holdShift = 0;
    }
  }

  // Natural minor degrees for the chord changes (i, VI, III, VII, iv, v)
  const MINOR = [0, 2, 3, 5, 7, 8, 10];
  const PROG = [0, 5, 2, 6, 3, 4];               // scale degrees of chord roots
  const ROMAN = ["i", "VI", "III", "VII", "iv", "v"];

  function init(ctx, dest) {
    ac = ctx; out = ac.createGain(); out.gain.value = 0.9;
    masterF = ac.createBiquadFilter(); masterF.type = "lowpass"; masterF.frequency.value = 20000; masterF.Q.value = 1.2;
    out.connect(masterF); masterF.connect(dest);
    noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    // dotted-8th delay for the lead
    delay = ac.createDelay(2); fb = ac.createGain(); delayWet = ac.createGain();
    delay.connect(fb); fb.connect(delay); delay.connect(delayWet); delayWet.connect(out);
    fb.gain.value = 0.35; delayWet.gain.value = 0.3;
  }
  const bpm = () => Number(document.getElementById("bpm").value) || 122;
  const spStep = () => 60 / bpm() / 4;

  function start() {
    if (!ac || timer) return;
    nextTime = ac.currentTime + 0.1; step = 0; bar = 0; calmBars = 0; breakdown = false; lastLead = null;
    delay.delayTime.value = spStep() * 3;
    timer = setInterval(schedule, 25);
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  const running = () => !!timer;

  function schedule() {
    const ahead = document.hidden ? 1.5 : 0.12;   // background tabs run timers slowly, so look further ahead
    while (nextTime < ac.currentTime + ahead) {
      playStep(step, nextTime);
      nextTime += spStep();
      step = (step + 1) % 16;
      if (step === 0) endOfBar();
    }
  }

  function endOfBar() {
    bar++;
    const meanAct = barSteps ? barActivity / barSteps : 0;
    barActivity = 0; barSteps = 0;
    calmBars = meanAct < 0.12 ? calmBars + 1 : 0;
    if (!breakdown && calmBars >= 8) { breakdown = true; }
    else if (breakdown && meanAct > 0.25) { breakdown = false; fillBar = bar; crashPending = true; }
    for (const k in mods) if (mods[k] > 0) mods[k]--;
    if (bar % 2 === 0) pickChord();
    out.gain.setTargetAtTime(touchPhase() === "drop" ? 1.15 : 0.9, ac.currentTime, 0.3);   // drops are louder
    delay.delayTime.setTargetAtTime(spStep() * 3, ac.currentTime, 0.1);
  }
  function pickChord() {
    if (touchPhase() === "drop" && dropProg) chordIdx = dropProg[(bar - buildEnd) % dropProg.length];
    else chordIdx = Math.min(PROG.length - 1, Math.floor(slowLevel * PROG.length));
  }

  // Called the moment a touch (plant sensor or T key), water (W) or light (L) happens.
  // Notes are only queued 0.12 s ahead, so the change is heard within about 0.25 s.
  function event(type) {
    if (type === "touch") {
      if (drumsOnly) return;                               // drums-only layer reacts through beatTouch()
      if (touchPhase() !== "drop") {                       // a new drop: move on to the next change
        touchCount++;
        const v = (touchCount - 1) % 4;
        dropShift = [5, 0, 7, 0][v];
        dropProg = v === 1 ? [1, 3, 0, 0] : null;         // VI VII i i
        dropDouble = v === 2;
        beatVar = v;
        state.variant = VARIANTS[v];
        buildEnd = bar;
      }
      dropEnd = bar + 8;                                   // touching during a drop keeps it going
      breakdown = false; calmBars = 0; lastLead = null;
      pickChord();
      if (ac && timer) {                                   // heard right now, not on the next bar
        const t = ac.currentTime + 0.01, cn = chordNotes(60);
        kick(t); crash(t); snare(t, 0.8);
        chordVoices(t, cn, 1.6, 0.18, 5000, 0.005);
        bassDive(t, 12);
        // the whole track is muffled for an instant, then opens over one beat: a "whoosh" into the drop
        masterF.frequency.cancelScheduledValues(t);
        masterF.frequency.setValueAtTime(250, t);
        masterF.frequency.exponentialRampToValueAtTime(20000, t + spStep() * 4);
        out.gain.setTargetAtTime(1.15, t, 0.05);
      }
      return;
    }
    if (!(type in mods)) return;
    mods[type] = 16;
    if (breakdown) { breakdown = false; calmBars = 0; }
  }

  // ---------------- musical helpers
  function keyRoot() {
    return Number(document.getElementById("root").value) % 12 + (mods.water > 0 ? 2 : 0) + (touchPhase() === "drop" ? dropShift : 0) + holdShift;
  }
  function scale() {
    if (mods.light > 0) return [0, 2, 4, 7, 9];    // major pentatonic: brighter mood
    const sel = document.getElementById("scaleSel").value;
    return (typeof SCALES !== "undefined" && SCALES[sel]) || MINOR;
  }
  function chordNotes(base) {                     // 7th chord stacked in natural minor
    const deg = PROG[chordIdx];
    return [0, 2, 4, 6].map(k => {
      const dd = deg + k;
      return base + keyRoot() + 12 * Math.floor(dd / 7) + MINOR[dd % 7];
    });
  }
  const mtof = n => 440 * Math.pow(2, (n - 69) / 12);

  function playStep(s, t) {
    // No plant data in the last second: play nothing at all. The music only exists while the plant is connected.
    if (performance.now() - lastSampleAt > 1000) { state.section = "waiting"; state.lead = state.bass = "-"; bar = 0; calmBars = 0; return; }
    slowLevel += 0.015 * (level - slowLevel);     // about 8 s memory at 122 BPM
    barActivity += activity; barSteps++;
    if (drumsOnly) { playDrums(s, t); return; }
    const intro = bar < 4, a = activity, plantOk = !noContact;   // only real contact loss silences the melodies
    state.section = breakdown ? "breakdown" : bar < 4 ? "intro" : bar < 12 ? "build" : "groove";
    const ph = touchPhase(), lift = ph === "drop" ? 1 : 0;
    if (held) { holdSteps++; holdShift = Math.min(12, Math.floor(holdSteps / 4)); }   // climb a semitone per beat
    if (s === 0 && ph === "drop" && dropProg) pickChord();
    const cn = chordNotes(48);
    state.chord = ROMAN[chordIdx];
    state.mood = [held && `HAND ON PLANT, pitch +${holdShift}`, ph === "drop" && `TOUCH DROP: ${state.variant}, ${dropEnd - bar} bars`,
                  mods.water && `water wash ${mods.water} bars`, mods.light && `light ${mods.light} bars`].filter(Boolean).join(", ");

    // HAND ON THE PLANT: the plant "plays" while touched
    if (held && plantOk) {
      const sorted = cn.slice().sort((x, y) => x - y), i = (bar * 16 + s) % 12;
      lead(t, sorted[i % 4] + 24 + 12 * Math.floor(i / 4) - 12, spStep() * 0.9, 0.45);
      hat(t, false, 0.35);
      if (s % 4 === 3) stab(t, cn.map(n => n + 12), spStep(), 0.6);
    }

    // DRUMS (the frame)
    const kickOn = (!intro || lift) && !breakdown;
    // Beat switch: each touch drop has its own drum pattern
    const pat = lift ? beatVar : 3;
    let k, cl = false, sn = false, ghost = false;
    if (pat === 0) { k = s === 0 || s === 10; sn = s === 8; }                                   // half-time: slow and heavy
    else if (pat === 1) { k = s === 0 || s === 7 || s === 10; sn = s === 4 || s === 12; ghost = s === 14 || s === 9; } // breakbeat
    else if (pat === 2) { k = s % 4 === 0 || s === 14; sn = s % 4 === 2; }                     // double-time: snare every half beat
    else { k = s % 4 === 0; cl = s === 4 || s === 12; }                                         // house: four on the floor
    if (kickOn && k) kick(t);
    if (kickOn && cl) clap(t);
    if (kickOn && sn) snare(t, 0.7);
    if (kickOn && ghost) snare(t, 0.25);
    if (s % 4 === 2) hat(t, true, 0.35 + 0.3 * a);                       // offbeat open hat
    if (!intro && s % 2 === 1 && (a > 0.35 || lift)) hat(t, false, 0.15 + 0.35 * Math.max(a, 0.5 * lift)); // busier when active or in a drop
    if (lift && dropDouble && s % 2 === 0 && s % 4 !== 2) hat(t, false, 0.3);                            // double-time hats
    if (fillBar === bar && s >= 12) clap(t, 0.6);                          // fill coming out of a breakdown
    if (crashPending && s === 0) { crash(t); crashPending = false; }

    // BASS: offbeat 8ths on the chord root, octave jumps when the plant is high
    if ((bar >= 8 || lift) && !breakdown && plantOk && (s % 4 === 2 || (a > 0.6 && s % 8 === 3))) {
      const root = cn[0] - 24;
      const n = level > 0.7 && s % 8 === 6 ? root + 12 : level < 0.2 && s % 8 === 6 ? root + 7 : root;
      bass(t, n, spStep() * 1.6, 250 + 2200 * Math.pow(level, 1.5) + 1500 * lift);
      state.bass = noteName(n);
    }
    // WATER: warm pad layer under everything while the wash lasts
    if (mods.water > 0 && plantOk && s === 0 && bar % 2 === 0 && !breakdown) pad(t, chordNotes(60), spStep() * 32);

    // CHORDS: stabs on 1 and the "and" of 3, a held pad in breakdowns
    if (plantOk) {
      if (breakdown && s === 0 && bar % 2 === 0) pad(t, cn, spStep() * 32);
      else if (!breakdown && !intro && (s === 0 || s === 10 || (lift && s === 6))) stab(t, cn, spStep() * 1.5, 0.5 + 0.3 * a + 0.2 * lift);
      else if (intro && s === 0) pad(t, cn, spStep() * 16);
    }

    // LEAD: plant level picks the note (scale over two octaves, chord tones on strong beats),
    // activity decides how many notes play
    if ((bar >= 12 || lift) && plantOk) {
      const strong = s % 4 === 0, eighth = s % 2 === 0;
      const gate = strong ? 0.08 : eighth ? 0.3 - 0.25 * lift : 0.65;
      if (a >= gate) {
        const sc = scale(), steps = sc.length * 2;
        const pos = Math.round(level * (steps - 1));
        let n = 72 + keyRoot() - 12 + 12 * lift + 12 * Math.floor(pos / sc.length) + sc[pos % sc.length];
        if (strong) {                              // snap to the nearest chord tone
          let best = n, bd = 99;
          for (const c of cn) for (const o of [-12, 0, 12, 24]) { const cand = c + o; if (Math.abs(cand - n) < bd) { bd = Math.abs(cand - n); best = cand; } }
          n = best;
        }
        if (n !== lastLead || s % 8 === 0) { lead(t, n, spStep() * (strong ? 2 : 1.2), 0.25 + 0.35 * a); lastLead = n; state.lead = noteName(n); }
      }
    }
  }

  // ---------------- sounds (all synthesised)
  function env(g, t, peak, attack, decay) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }
  function kick(t) {
    const o = ac.createOscillator(), g = ac.createGain();
    o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    env(g, t, 1.0, 0.002, 0.42); o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.5);
  }
  function noiseHit(t, type, freq, q, peak, decay, dest = out) {
    const src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    src.buffer = noise; f.type = type; f.frequency.value = freq; f.Q.value = q;
    env(g, t, peak, 0.001, decay); src.connect(f); f.connect(g); g.connect(dest);
    src.start(t, Math.random() * 0.5); src.stop(t + decay + 0.05);
  }
  function clap(t, v = 0.5) { [0, 0.012, 0.024].forEach(o => noiseHit(t + o, "bandpass", 1500, 1.2, v, 0.15)); }
  function hat(t, open, v) { noiseHit(t, "highpass", open ? 7000 : 9000, 0.7, v * 0.5, open ? 0.22 : 0.05); }
  function crash(t) { noiseHit(t, "highpass", 5000, 0.5, 0.45, 2.2); }
  function snare(t, v = 0.6) {
    noiseHit(t, "bandpass", 2200, 0.8, v * 0.6, 0.18);
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = "triangle"; o.frequency.setValueAtTime(220, t); o.frequency.exponentialRampToValueAtTime(160, t + 0.08);
    env(g, t, v * 0.5, 0.001, 0.12); o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.2);
  }
  // Deep sub that slides down by `semis` semitones: the "drop" feeling
  function bassDive(t, semis) {
    const o = ac.createOscillator(), g = ac.createGain(), base = mtof(24 + keyRoot() - holdShift);
    o.type = "sine";
    o.frequency.setValueAtTime(base * Math.pow(2, semis / 12) * 2, t);
    o.frequency.exponentialRampToValueAtTime(base, t + 0.7);
    env(g, t, 0.8, 0.005, 1.1); o.connect(g); g.connect(out); o.start(t); o.stop(t + 1.2);
  }
  function bass(t, n, dur, cutoff) {
    const o = ac.createOscillator(), sub = ac.createOscillator(), f = ac.createBiquadFilter(), g = ac.createGain();
    o.type = "sawtooth"; sub.type = "sine"; o.frequency.value = mtof(n); sub.frequency.value = mtof(n - 12);
    f.type = "lowpass"; f.Q.value = 6;
    f.frequency.setValueAtTime(cutoff * 2.5, t); f.frequency.exponentialRampToValueAtTime(Math.max(80, cutoff * 0.6), t + dur);
    env(g, t, 0.35, 0.005, dur);
    o.connect(f); sub.connect(f); f.connect(g); g.connect(out);
    o.start(t); sub.start(t); o.stop(t + dur + 0.05); sub.stop(t + dur + 0.05);
  }
  function chordVoices(t, notes, dur, peak, cutoff, attack) {
    const f = ac.createBiquadFilter(), g = ac.createGain();
    f.type = "lowpass"; f.frequency.value = cutoff; f.connect(g); g.connect(out);
    env(g, t, peak, attack, dur);
    notes.forEach(n => [-7, 7].forEach(cents => {
      const o = ac.createOscillator(); o.type = "sawtooth"; o.frequency.value = mtof(n); o.detune.value = cents;
      o.connect(f); o.start(t); o.stop(t + attack + dur + 0.1);
    }));
  }
  function stab(t, notes, dur, v) { chordVoices(t, notes, dur, 0.09 * v, 1200 + 2500 * activity + (touchPhase() === "drop" ? 3000 : 0), 0.005); }
  // Rising filtered noise for the touch build
  function riser(t, dur) {
    const src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    src.buffer = noise; src.loop = true; f.type = "bandpass"; f.Q.value = 2;
    f.frequency.setValueAtTime(400, t); f.frequency.exponentialRampToValueAtTime(9000, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + dur); g.gain.linearRampToValueAtTime(0, t + dur + 0.02);
    src.connect(f); f.connect(g); g.connect(out); src.start(t); src.stop(t + dur + 0.05);
  }
  function pad(t, notes, dur) { chordVoices(t, notes, dur, 0.06, 900, dur * 0.3); }
  function lead(t, n, dur, v) {
    const o = ac.createOscillator(), o2 = ac.createOscillator(), g = ac.createGain();
    o.type = "triangle"; o2.type = "sine"; o.frequency.value = mtof(n); o2.frequency.value = mtof(n + 12);
    env(g, t, 0.22 * v, 0.004, dur);
    o.connect(g); o2.connect(g); g.connect(out); g.connect(delay);
    o.start(t); o2.start(t); o.stop(t + dur + 0.05); o2.stop(t + dur + 0.05);
  }

  // A detected plant response: crash and a big chord now, fill at the end of the bar
  function response() {
    if (!timer) return;
    const t = ac.currentTime + 0.02;
    crash(t); chordVoices(t, chordNotes(60), 1.2, 0.12, 3500, 0.01);
    fillBar = bar;
  }

  return { init, start, stop, running, response, event, touchHold, setDrumsOnly, setVolume, beatTouch, state, get bar() { return bar; } };
})();

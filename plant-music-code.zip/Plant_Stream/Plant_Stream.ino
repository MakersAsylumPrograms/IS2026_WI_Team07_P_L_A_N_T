// Plant_Stream: two-plant sensor with touch sensing on the leaf electrode itself.
//
// Every 20 ms (one 50 Hz cycle, so mains hum cancels):
//   18 ms: soil reference ON (DAC about 1.1 V on D25 / D26), leaf voltage averaged -> Raw (the plant signal)
//    2 ms: soil reference RELEASED (DAC pins high-impedance), ESP32 touch sensing on the leaf electrode
//          -> Touch. With the plant no longer held at 1.1 V, a finger on the plant is a big part of what the
//          touch sensor measures, so Touch drops clearly when the plant is touched.
//
// 50 times a second it sends:  Raw_mV:1016.2,Touch:230,Raw2_mV:1003.1,Touch2:241
//
// Wiring (red leads moved to touch-capable pins):
//   Plant 1: Red (leaf) -> D32   Yellow (soil) -> D25
//   Plant 2: Red (leaf) -> D33   Yellow (soil) -> D26
//   Black leads: not used
//
// History: D4 touch pin (13 Nov), body hum (14 Nov) and a 1 kHz test signal (14 Nov) were tried first.
// All failed with good soil contact because the reference held the plant too firmly to feel a finger.

#include <Arduino.h>


#define PIN1         32      // ADC1 + touch T9
#define PIN2         33      // ADC1 + touch T8
#define BIAS1        25
#define BIAS2        26
#define BIAS_LEVEL   85      // about 1.1 V
#define ADC_US       17000   // reference on, measuring the plant
#define READS        34      // one reading every 500 us
#define SUB          2
#define TOUCH_AVG    2

static inline void waitUntil(unsigned long t) { while ((long)(micros() - t) < 0) { } }

void refOn()  { dacWrite(BIAS1, BIAS_LEVEL); dacWrite(BIAS2, BIAS_LEVEL); }
void refOff() { dacDisable(BIAS1); dacDisable(BIAS2);       // GPIO25 / GPIO26 float
                pinMode(BIAS1, INPUT); pinMode(BIAS2, INPUT); }

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(PIN1, ADC_11db);
  analogSetPinAttenuation(PIN2, ADC_11db);
  refOn();
}

void loop() {
  unsigned long start = micros();

  // 1) plant signal with the reference on
  refOn();
  waitUntil(start + 1000);                 // let the plant settle back after the touch phase
  long s1 = 0, s2 = 0;
  unsigned long t = micros();
  for (int i = 0; i < READS; i++) {
    for (int k = 0; k < SUB; k++) { s1 += analogReadMilliVolts(PIN1); s2 += analogReadMilliVolts(PIN2); }
    t += 500; waitUntil(t);
  }

  // 2) touch with the reference released
  refOff();
  long t1 = 0, t2 = 0;
  for (int k = 0; k < TOUCH_AVG; k++) { t1 += touchRead(PIN1); t2 += touchRead(PIN2); }
  refOn();

  // the touch peripheral leaves the pins in touch mode; give them back to the ADC
  analogSetPinAttenuation(PIN1, ADC_11db);
  analogSetPinAttenuation(PIN2, ADC_11db);

  const float n = READS * SUB;
  Serial.print("Raw_mV:");   Serial.print(s1 / n, 1);
  Serial.print(",Touch:");   Serial.print(t1 / TOUCH_AVG);
  Serial.print(",Raw2_mV:"); Serial.print(s2 / n, 1);
  Serial.print(",Touch2:");  Serial.println(t2 / TOUCH_AVG);

  waitUntil(start + 20000);                // one line every 20 ms
}

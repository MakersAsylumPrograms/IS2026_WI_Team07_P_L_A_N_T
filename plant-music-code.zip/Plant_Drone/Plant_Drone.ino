/*------------
Plant_Drone: plant signal -> one continuous drone that dances in pitch (BLE MIDI, ESP32)

Two modes (set DRONE_MODE below):
 0 GLIDE  : one held note. The plant level bends its pitch smoothly up and down
            (pitch bend, up to +/- BEND_RANGE semitones).
 1 LADDER : the plant level climbs the harmonic series of the root note
            (root, octave, fifth, octave, third, fifth, flat seventh, octave).
            Steps overlap so they slide into each other. Inside a step the pitch
            still wobbles with the signal, and pitch bend tunes each harmonic to
            its true (just) pitch.
Both modes:
 - Mod wheel (CC1) follows how fast the plant signal is changing (activity)
 - Expression (CC11) swells louder when the plant is active

Wiring:
  Red lead (IN+)    -> D34  (electrode on underside of a leaf)
  Yellow lead (REF) -> D25  (electrode in wet soil)

Partition scheme: Huge APP. BLE name: "Plant Drone".
GarageBand: pick a sustained sound (Keyboard > Synth pads, or Strings).
GarageBand pitch bend range is 2 semitones by default, so keep BEND_RANGE at 2.
Serial: 115200 baud, one line per sample (works with Serial Plotter and the logger).
-------------*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>

//****************************** SETTINGS
#define DRONE_MODE     1         // 0 = GLIDE, 1 = LADDER

#define INPUT_PIN      34
#define BIAS_PIN       25
#define BIAS_LEVEL     85        // About 1.1V
#define LED_PIN        2

#define SAMPLE_HZ      50
#define OVERSAMPLE     64
#define CALIBRATE_S    10

int   rootNote       = 36;       // Drone root (36 = C2)
int   topHarmonic    = 8;        // LADDER: highest harmonic used (2 to 16)
float bendRange      = 2.0;      // Must match the synth's pitch bend range (GarageBand = 2)
float danceSemis     = 0.6;      // LADDER: pitch wobble inside one step, in semitones
float minRangeMv     = 4.0;      // Smallest range spread across the slider. Raise if noise alone moves it
float hysteresis     = 0.3;      // LADDER: 0 to 0.5, higher = fewer step changes
float rateFullMvS    = 5.0;      // Activity (mV per second) that gives full mod wheel
int   overlapMs      = 120;      // LADDER: old note keeps sounding this long after a step
int   velocity       = 80;
int   channel        = 1;
//******************************

float smoothMv = 0, prevSmooth = 0, rateMvS = 0, activity = 0;
float minMv = 0, maxMv = 0, level = 0;
bool  started = false;

int   currentNote = -1, oldNote = -1, currentHarm = -1;
unsigned long oldNoteOffAt = 0, lastSample = 0, lastBendAt = 0, lastCCAt = 0, startAt = 0;
int   lastBend = -1, lastMod = -1, lastExpr = -1;

//****************************** Bluetooth MIDI
#define MIDI_SERVICE_UUID "03b80e5a-ede8-4b33-a751-6ce34ec4c700"
#define MIDI_CHAR_UUID    "7772e5db-3868-4112-a1a9-f2669d106bf3"
BLECharacteristic *midiChar = nullptr;
volatile bool bleConnected = false;
volatile bool needRestart = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *s) { bleConnected = true; needRestart = true; }
  void onDisconnect(BLEServer *s) { bleConnected = false; s->startAdvertising(); }
};

void setupBLE() {
  BLEDevice::init("Plant Drone");
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(MIDI_SERVICE_UUID);
  midiChar = service->createCharacteristic(MIDI_CHAR_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE_NR | BLECharacteristic::PROPERTY_NOTIFY);
  midiChar->addDescriptor(new BLE2902());
  service->start();
  BLEAdvertising *adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(MIDI_SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void midiSend(uint8_t type, uint8_t d1, uint8_t d2) {
  if (!bleConnected) return;
  unsigned long t = millis() & 0x1FFF;
  uint8_t pkt[5] = {
    (uint8_t)(0x80 | (t >> 7)), (uint8_t)(0x80 | (t & 0x7F)),
    (uint8_t)(type | ((channel - 1) & 0x0F)), (uint8_t)(d1 & 0x7F), (uint8_t)(d2 & 0x7F)
  };
  midiChar->setValue(pkt, 5);
  midiChar->notify();
}
void noteOn(int n, int v)         { midiSend(0x90, n, v); }
void noteOff(int n)               { midiSend(0x80, n, 0); }
void controlChange(int cc, int v) { midiSend(0xB0, cc, v); }
void pitchBend(int value)         { midiSend(0xE0, value & 0x7F, (value >> 7) & 0x7F); }  // 0..16383, 8192 = centre

//****************************** Setup and loop
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  dacWrite(BIAS_PIN, BIAS_LEVEL);
  analogReadResolution(12);
  analogSetPinAttenuation(INPUT_PIN, ADC_11db);
  setupBLE();
  startAt = millis();
}

void loop() {
  unsigned long now = millis();
  if (now - lastSample < 1000 / SAMPLE_HZ) return;
  lastSample = now;

  float rawMv = readPlant();
  updateRange();

  float bendSemis = 0;
  int harm = 0;
  bool calibrating = (now - startAt) < (unsigned long)CALIBRATE_S * 1000;

  if (calibrating) {
    digitalWrite(LED_PIN, (now / 250) % 2);
  } else {
    if (needRestart) restartDrone();
    if (DRONE_MODE == 0) bendSemis = glide();
    else                 bendSemis = ladder(now, harm);
    sendBend(now, bendSemis);
    sendControls(now);
    digitalWrite(LED_PIN, bleConnected ? HIGH : (now / 1000) % 2);
  }

  // One CSV-friendly line per sample (labels work in Serial Plotter too)
  Serial.print("Raw_mV:");      Serial.print(rawMv, 1);
  Serial.print(",Level_%:");    Serial.print(level * 100, 1);
  Serial.print(",Activity_%:"); Serial.print(activity * 100, 1);
  Serial.print(",Bend_st:");    Serial.print(bendSemis, 2);
  Serial.print(",Harmonic:");   Serial.println(harm);
}

//****************************** Reading
float readPlant() {
  long sum = 0;
  for (int i = 0; i < OVERSAMPLE; i++) sum += analogReadMilliVolts(INPUT_PIN);
  float mv = sum / (float)OVERSAMPLE;
  if (!started) { smoothMv = prevSmooth = minMv = maxMv = mv; started = true; }
  prevSmooth = smoothMv;
  smoothMv += 0.08 * (mv - smoothMv);                    // ~0.25 s smoothing
  float rate = (smoothMv - prevSmooth) * SAMPLE_HZ;      // mV per second
  rateMvS += 0.1 * (rate - rateMvS);
  activity = constrain(fabs(rateMvS) / rateFullMvS, 0.0, 1.0);
  return mv;
}

// Range stretches to new extremes and slowly shrinks back (~40 s)
void updateRange() {
  if (smoothMv > maxMv) maxMv = smoothMv; else maxMv -= (maxMv - smoothMv) * 0.0005;
  if (smoothMv < minMv) minMv = smoothMv; else minMv += (smoothMv - minMv) * 0.0005;
  if (maxMv - minMv < minRangeMv) {
    float mid = (maxMv + minMv) / 2;
    maxMv = mid + minRangeMv / 2;
    minMv = mid - minRangeMv / 2;
  }
  level = constrain((smoothMv - minMv) / (maxMv - minMv), 0.0, 1.0);
}

//****************************** Drone voices
void restartDrone() {
  needRestart = false;
  if (currentNote >= 0) noteOff(currentNote);
  if (oldNote >= 0) noteOff(oldNote);
  oldNote = -1;
  currentHarm = -1;
  lastBend = lastMod = lastExpr = -1;
  if (DRONE_MODE == 0) {
    currentNote = rootNote + 12;                         // Glide voice sits one octave above root
    noteOn(currentNote, velocity);
  } else {
    currentNote = -1;                                    // Ladder picks its first note itself
  }
}

// GLIDE: level 0..1 maps to -bendRange..+bendRange semitones
float glide() {
  return (level * 2.0 - 1.0) * bendRange;
}

// LADDER: level picks harmonic 1..topHarmonic, steps overlap, bend tunes and wobbles
float ladder(unsigned long now, int &harmOut) {
  int steps = topHarmonic;                               // harmonics 1..topHarmonic
  float pos = level * (steps - 1);                       // 0..steps-1

  int idx = currentHarm < 0 ? -1 : currentHarm - 1;
  if (idx < 0 || fabs(pos - idx) > 0.5 + hysteresis) {
    idx = constrain((int)round(pos), 0, steps - 1);
  }
  int harm = idx + 1;

  float exactSemis = 12.0 * log2f((float)harm);          // true pitch of this harmonic above root
  int   nearest    = (int)round(exactSemis);
  float tuneSemis  = exactSemis - nearest;               // e.g. 7th harmonic is 0.31 st flat

  if (harm != currentHarm) {
    int note = rootNote + nearest;
    if (oldNote >= 0) noteOff(oldNote);                  // finish any earlier overlap
    if (currentNote >= 0 && currentNote != note) {
      oldNote = currentNote;
      oldNoteOffAt = now + overlapMs;
    }
    if (currentNote != note) noteOn(note, velocity);
    currentNote = note;
    currentHarm = harm;
  }
  if (oldNote >= 0 && now >= oldNoteOffAt) { noteOff(oldNote); oldNote = -1; }

  float inside = constrain(pos - idx, -0.5, 0.5);        // where the level sits inside this step
  harmOut = harm;
  return constrain(tuneSemis + inside * danceSemis, -bendRange, bendRange);
}

//****************************** MIDI controls
void sendBend(unsigned long now, float semis) {
  if (now - lastBendAt < 30) return;                     // keep BLE traffic sane
  int value = 8192 + (int)(semis / bendRange * 8191);
  value = constrain(value, 0, 16383);
  if (abs(value - lastBend) < 24) return;
  lastBendAt = now;
  lastBend = value;
  pitchBend(value);
}

void sendControls(unsigned long now) {
  if (now - lastCCAt < 60) return;
  lastCCAt = now;
  int mod = (int)(activity * 127);
  if (abs(mod - lastMod) >= 2) { controlChange(1, mod); lastMod = mod; }
  int expr = 70 + (int)(activity * 57);                  // never fully silent
  if (abs(expr - lastExpr) >= 2) { controlChange(11, expr); lastExpr = expr; }
}

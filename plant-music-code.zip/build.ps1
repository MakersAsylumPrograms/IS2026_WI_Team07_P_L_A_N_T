# Build and optionally upload a sketch.
# Usage:
#   .\build.ps1 Plant_Drone            compile only
#   .\build.ps1 Plant_Drone -Upload    compile and upload to COM3
#   .\build.ps1 Plant_Drone -Upload -Monitor   then open serial monitor
param(
  [Parameter(Mandatory = $true)][string]$Sketch,
  [switch]$Upload,
  [switch]$Monitor,
  [string]$Port = "COM3"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$cli = (Get-Command arduino-cli -ErrorAction SilentlyContinue).Source
if (-not $cli) { $cli = "C:\Program Files\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe" }
if (-not (Test-Path $cli)) { throw "arduino-cli not found" }

if (-not (Test-Path "$Sketch\$Sketch.ino")) { throw "No sketch at $Sketch\$Sketch.ino" }

# Bluetooth sketches need the Huge APP partition scheme
$fqbn = "esp32:esp32:esp32"
if (Select-String -Path "$Sketch\$Sketch.ino" -Pattern "BLEDevice.h" -Quiet) {
  $fqbn = "esp32:esp32:esp32:PartitionScheme=huge_app"
}

Write-Host "Compiling $Sketch ($fqbn)"
& $cli compile --fqbn $fqbn --build-path "build\$Sketch" $Sketch
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if ($Upload) {
  Write-Host "Uploading to $Port"
  & $cli upload -p $Port --fqbn $fqbn --input-dir "build\$Sketch" $Sketch
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

if ($Monitor) {
  & $cli monitor -p $Port --config baudrate=115200
}

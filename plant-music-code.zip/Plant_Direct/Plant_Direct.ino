// Plant Direct: electrodes direct to ESP32, no BioAmp, no resistors needed
// Wiring:
//   Red lead (IN+)  -> D34   (electrode on underside of a leaf)
//   Yellow lead (REF) -> D25 (electrode in wet soil)
//   Black lead (IN-) -> not used
// D25 outputs a steady ~1.1V bias, so the plant signal can swing up and down around it.
// Open Serial Plotter at 115200 baud. Wait 1 to 2 minutes for the reading to settle.

#define INPUT_PIN    34
#define BIAS_PIN     25      // ESP32 built-in DAC output
#define BIAS_LEVEL   85      // 0 to 255. 85 = about 1.1V
#define OVERSAMPLE   128     // Readings averaged per output point (reduces noise)
#define OUTPUT_HZ    25      // Points per second on the plotter (10 = slow, 25 = medium, 40 = fast)
#define PLOT_MODE    1       // 1 = Serial Plotter view (Plant signal + guide lines)
                             // 0 = Serial Monitor check (shows Pin_mV for wiring checks)
#define GUIDE_MV     5       // Guide lines at +5 and -5 mV keep the plotter scale steady

float baseline = 0;
float smooth = 0;
bool started = false;
unsigned long lastPrint = 0;

void setup() {
  Serial.begin(115200);
  dacWrite(BIAS_PIN, BIAS_LEVEL);
  analogReadResolution(12);
  analogSetPinAttenuation(INPUT_PIN, ADC_11db);
  delay(500);
}

void loop() {
  if (millis() - lastPrint < 1000 / OUTPUT_HZ) return;
  lastPrint = millis();

  // Average many readings in millivolts
  long sum = 0;
  for (int i = 0; i < OVERSAMPLE; i++) {
    sum += analogReadMilliVolts(INPUT_PIN);
  }
  float mv = sum / (float)OVERSAMPLE;

  if (!started) {
    baseline = mv;
    smooth = mv;
    started = true;
  }

  smooth += (2.0 / OUTPUT_HZ) * (mv - smooth);         // Light smoothing (same feel at any rate)
  baseline += (0.02 / OUTPUT_HZ) * (smooth - baseline); // Very slow drift removal (about 50 s)

  if (PLOT_MODE == 0) {
    Serial.print("Pin_mV:");
    Serial.print(mv, 1);                    // Actual voltage on D34 (should settle near 1100)
    Serial.print(",Plant_mV:");
    Serial.println(smooth - baseline, 2);
  } else {
    Serial.print("Plant_mV:");
    Serial.print(smooth - baseline, 2);     // Change from resting level, in mV
    Serial.print(",Upper:");
    Serial.print(GUIDE_MV);
    Serial.print(",Lower:");
    Serial.print(-GUIDE_MV);
    Serial.print(",Zero:");
    Serial.println(0);
  }
}

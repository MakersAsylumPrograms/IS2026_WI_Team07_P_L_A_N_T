/*------------
Plant_Melody: plant signal -> melody + drone over Bluetooth MIDI (ESP32)

How it works:
 - Reads the plant voltage on D34 (D25 gives a ~1.1V bias)
 - Learns the plant's own range automatically (self-calibrating)
 - MELODY: the plant's level picks the note. Higher voltage = higher note in the scale.
           A new note plays only when the level moves into a different band.
 - LOUDNESS: how fast the signal is changing sets how hard each note is played
 - DRONE: a low held note, with its modulation following how active the plant is

Wiring:
  Red lead (IN+)    -> D34  (electrode on underside of a leaf)
  Yellow lead (REF) -> D25  (electrode in wet soil)

Arduino IDE: Tools > Partition Scheme > "Huge APP (3MB No OTA/1MB SPIFFS)"
Phone: GarageBand > instrument > Settings > Advanced > Bluetooth MIDI Devices > "Plant Melody"
Serial Plotter: 115200 baud
-------------*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>

//****************************** SETTINGS
#define INPUT_PIN      34
#define BIAS_PIN       25
#define BIAS_LEVEL     85        // About 1.1V
#define LED_PIN        2

#define SAMPLE_HZ      50        // Readings per second
#define OVERSAMPLE     64        // ADC readings averaged per sample
#define CALIBRATE_S    10        // Seconds of listening before music starts

int   scaleChoice    = 0;        // 0 Pentatonic, 1 Major, 2 Minor, 3 Bhairav (Indian)
int   baseNote       = 48;       // Lowest melody note (48 = C3)
int   octaves        = 2;        // Melody range in octaves
float minRangeMv     = 4.0;      // Smallest range spread across the scale. Raise if noise alone plays notes
float hysteresis     = 0.35;     // 0 to 0.5. Higher = steadier, fewer note changes
float rateFullMvS    = 5.0;      // Change speed (mV per second) that gives maximum loudness
int   minGapMs       = 180;      // Shortest time between melody notes
int   maxHoldMs      = 1500;     // Longest a melody note is held
bool  droneOn        = true;     // Low held note in the background
int   channel        = 1;
//******************************

const int scales[4][8] = {
  {5, 0, 2, 4, 7, 9},            // Pentatonic (always sounds good)
  {7, 0, 2, 4, 5, 7, 9, 11},     // Major
  {7, 0, 2, 3, 5, 7, 8, 10},     // Minor
  {7, 0, 1, 4, 5, 7, 8, 11}      // Bhairav
};

float smoothMv = 0, prevSmooth = 0, rateMvS = 0;
float minMv = 0, maxMv = 0;
float level = 0;                 // 0 to 1, position in the learned range
int   currentBand = -1;
int   currentNote = -1;
unsigned long noteOnAt = 0, lastNoteAt = 0, lastSample = 0, lastCC = 0, startAt = 0;
int   lastModValue = -1;
bool  started = false, droneSent = false;

//****************************** Bluetooth MIDI
#define MIDI_SERVICE_UUID "03b80e5a-ede8-4b33-a751-6ce34ec4c700"
#define MIDI_CHAR_UUID    "7772e5db-3868-4112-a1a9-f2669d106bf3"
BLECharacteristic *midiChar = nullptr;
bool bleConnected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *s) { bleConnected = true; droneSent = false; }
  void onDisconnect(BLEServer *s) { bleConnected = false; s->startAdvertising(); }
};

void setupBLE() {
  BLEDevice::init("Plant Melody");
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(MIDI_SERVICE_UUID);
  midiChar = service->createCharacteristic(MIDI_CHAR_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE_NR | BLECharacteristic::PROPERTY_NOTIFY);
  midiChar->addDescriptor(new BLE2902());
  service->start();
  BLEAdvertising *adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(MIDI_SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void midiSend(byte type, byte data1, byte data2) {
  if (!bleConnected) return;
  unsigned long t = millis() & 0x1FFF;
  uint8_t pkt[5] = {
    (uint8_t)(0x80 | (t >> 7)), (uint8_t)(0x80 | (t & 0x7F)),
    (uint8_t)(type | ((channel - 1) & 0x0F)), (uint8_t)(data1 & 0x7F), (uint8_t)(data2 & 0x7F)
  };
  midiChar->setValue(pkt, 5);
  midiChar->notify();
}
void noteOn(int n, int v) { midiSend(0x90, n, v); }
void noteOff(int n)       { midiSend(0x80, n, 0); }
void controlChange(int cc, int v) { midiSend(0xB0, cc, v); }

//****************************** Setup and loop
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  dacWrite(BIAS_PIN, BIAS_LEVEL);
  analogReadResolution(12);
  analogSetPinAttenuation(INPUT_PIN, ADC_11db);
  setupBLE();
  startAt = millis();
}

void loop() {
  unsigned long now = millis();
  if (now - lastSample < 1000 / SAMPLE_HZ) return;
  lastSample = now;

  readPlant();
  updateRange();

  bool calibrating = (now - startAt) < (unsigned long)CALIBRATE_S * 1000;
  if (calibrating) {
    digitalWrite(LED_PIN, (now / 250) % 2);   // Fast blink while learning
  } else {
    playDrone(now);
    playMelody(now);
  }
  printPlot();
}

//****************************** Reading
void readPlant() {
  long sum = 0;
  for (int i = 0; i < OVERSAMPLE; i++) sum += analogReadMilliVolts(INPUT_PIN);
  float mv = sum / (float)OVERSAMPLE;

  if (!started) {
    smoothMv = prevSmooth = minMv = maxMv = mv;
    started = true;
  }
  prevSmooth = smoothMv;
  smoothMv += 0.08 * (mv - smoothMv);                    // ~0.25 s smoothing
  float rate = (smoothMv - prevSmooth) * SAMPLE_HZ;      // mV per second
  rateMvS += 0.1 * (rate - rateMvS);
}

// Self-calibration: range stretches to fit new extremes and slowly shrinks back (~40 s)
void updateRange() {
  if (smoothMv > maxMv) maxMv = smoothMv; else maxMv -= (maxMv - smoothMv) * 0.0005;
  if (smoothMv < minMv) minMv = smoothMv; else minMv += (smoothMv - minMv) * 0.0005;

  if (maxMv - minMv < minRangeMv) {                      // Keep noise from filling the scale
    float mid = (maxMv + minMv) / 2;
    maxMv = mid + minRangeMv / 2;
    minMv = mid - minRangeMv / 2;
  }
  level = constrain((smoothMv - minMv) / (maxMv - minMv), 0.0, 1.0);
}

//****************************** Melody
int bandToNote(int band) {
  int len = scales[scaleChoice][0];
  int octave = band / len;
  int degree = band % len;
  return baseNote + 12 * octave + scales[scaleChoice][1 + degree];
}

void playMelody(unsigned long now) {
  int totalBands = scales[scaleChoice][0] * octaves + 1;
  float pos = level * (totalBands - 1);

  // Hysteresis: only change band once the level is clearly inside a new one
  int band = currentBand;
  if (currentBand < 0 || fabs(pos - currentBand) > 0.5 + hysteresis) {
    band = constrain((int)round(pos), 0, totalBands - 1);
  }

  if (band != currentBand && now - lastNoteAt >= (unsigned long)minGapMs) {
    int note = bandToNote(band);
    int velocity = map((int)(constrain(fabs(rateMvS) / rateFullMvS, 0.0, 1.0) * 100), 0, 100, 45, 120);
    if (currentNote >= 0) noteOff(currentNote);
    noteOn(note, velocity);
    currentNote = note;
    currentBand = band;
    noteOnAt = lastNoteAt = now;
    digitalWrite(LED_PIN, HIGH);
  }

  if (currentNote >= 0 && now - noteOnAt >= (unsigned long)maxHoldMs) {
    noteOff(currentNote);
    currentNote = -1;
  }
  if (now - noteOnAt > 120) digitalWrite(LED_PIN, LOW);
}

//****************************** Drone
void playDrone(unsigned long now) {
  if (!droneOn) return;
  if (bleConnected && !droneSent) {
    noteOn(baseNote - 12, 55);           // Root note, one octave below the melody
    droneSent = true;
  }
  // Modulation wheel (CC1) follows how active the plant is
  if (now - lastCC >= 60) {
    lastCC = now;
    int mod = (int)(constrain(fabs(rateMvS) / rateFullMvS, 0.0, 1.0) * 127);
    if (abs(mod - lastModValue) >= 2) {
      controlChange(1, mod);
      lastModValue = mod;
    }
  }
}

//****************************** Plotter
void printPlot() {
  Serial.print("Level_%:");
  Serial.print(level * 100, 1);
  Serial.print(",Activity_%:");
  Serial.print(constrain(fabs(rateMvS) / rateFullMvS, 0.0, 1.0) * 100, 1);
  Serial.print(",Note:");
  Serial.println(currentNote >= 0 ? currentNote : 0);
}

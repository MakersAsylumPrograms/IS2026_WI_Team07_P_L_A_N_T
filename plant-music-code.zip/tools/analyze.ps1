# Summarise plant recordings (CSV from the browser instrument or Plant_Stream).
# Usage:
#   .\tools\analyze.ps1 data\file1.csv data\file2.csv
#   .\tools\analyze.ps1 data\*.csv
# Per file: length, average pin voltage, noise, glitches, size of the slow wave,
# its dominant period (and how regular it is), and the change after each marked event.
param([Parameter(Mandatory = $true, ValueFromRemainingArguments = $true)][string[]]$Paths)

function Analyze([string]$path) {
  $lines = [IO.File]::ReadAllLines((Resolve-Path $path))
  $header = $null; $t = New-Object Collections.Generic.List[double]; $raw = New-Object Collections.Generic.List[double]
  $events = New-Object Collections.Generic.List[object]
  foreach ($l in $lines) {
    if ($l.StartsWith("#") -or -not $l.Trim()) { continue }
    $c = $l.Split(",")
    if (-not $header) { $header = $c; $ti = [array]::IndexOf($c, "t_s"); $ri = [array]::IndexOf($c, "raw_mv"); $ei = [array]::IndexOf($c, "event"); continue }
    $v = 0.0; if (-not [double]::TryParse($c[$ri], [ref]$v)) { continue }
    $raw.Add($v); $t.Add([double]$c[$ti])
    if ($ei -ge 0 -and $c.Count -gt $ei -and $c[$ei].Trim()) { $events.Add([pscustomobject]@{ i = $raw.Count - 1; type = $c[$ei].Trim() }) }
  }
  $n = $raw.Count; $t0 = $t[0]; $dur = $t[$n - 1] - $t0

  # noise and glitches
  $bad = 0; $ss = 0.0; $cnt = 0
  for ($i = 1; $i -lt $n; $i++) {
    $d = $raw[$i] - $raw[$i - 1]
    if ($raw[$i] -lt 300 -or [math]::Abs($d) -gt 50) { $bad++ } else { $ss += $d * $d; $cnt++ }
  }
  $noise = [math]::Sqrt($ss / [math]::Max(1, $cnt) / 2)
  $avg = ($raw | Measure-Object -Average).Average

  # 10 Hz copy, remove 30 s moving average -> slow wave
  $ds = New-Object Collections.Generic.List[double]
  for ($i = 0; $i + 5 -le $n; $i += 5) { $ds.Add(($raw[$i] + $raw[$i+1] + $raw[$i+2] + $raw[$i+3] + $raw[$i+4]) / 5) }
  $M = $ds.Count; $pre = New-Object double[] ($M + 1)
  for ($i = 0; $i -lt $M; $i++) { $pre[$i + 1] = $pre[$i] + $ds[$i] }
  $det = New-Object double[] $M; $w = 150
  for ($i = 0; $i -lt $M; $i++) { $a = [math]::Max(0, $i - $w); $b = [math]::Min($M, $i + $w + 1); $det[$i] = $ds[$i] - ($pre[$b] - $pre[$a]) / ($b - $a) }
  $mu = 0.0; foreach ($x in $det) { $mu += $x }; $mu /= $M
  $var = 0.0; foreach ($x in $det) { $var += ($x - $mu) * ($x - $mu) }
  $sd = [math]::Sqrt($var / $M)
  $sorted = $det.Clone(); [array]::Sort($sorted)
  $p2p = $sorted[[int]($M * 0.98)] - $sorted[[int]($M * 0.02)]

  # dominant period: best autocorrelation peak between 3 and 120 s
  $bestLag = 0; $bestR = 0.0; $prevR = 1.0; $rising = $false
  $maxLag = [math]::Min(1200, [int]($M / 2))
  for ($lag = 30; $lag -le $maxLag; $lag += 2) {
    $s = 0.0; for ($i = 0; $i -lt $M - $lag; $i += 2) { $s += ($det[$i] - $mu) * ($det[$i + $lag] - $mu) }
    $r = 2 * $s / $var
    if ($r -gt $prevR) { $rising = $true } elseif ($rising -and $prevR -gt $bestR) { $bestR = $prevR; $bestLag = $lag - 2; $rising = $false } else { $rising = $false }
    $prevR = $r
  }

  # events: change in the 20 s after vs the 20 s before, in units of the before sd
  $ev = @()
  foreach ($e in $events) {
    $te = $t[$e.i]; $b4 = @(); $af = @()
    for ($i = 0; $i -lt $n; $i++) { $dt = $t[$i] - $te; if ($dt -ge -20 -and $dt -lt 0) { $b4 += $raw[$i] } elseif ($dt -ge 0 -and $dt -lt 20) { $af += $raw[$i] } }
    if ($b4.Count -gt 50 -and $af.Count -gt 50) {
      $bm = ($b4 | Measure-Object -Average).Average; $bs = [math]::Sqrt((($b4 | % { ($_ - $bm) * ($_ - $bm) }) | Measure-Object -Average).Average)
      $am = ($af | Measure-Object -Average).Average
      $ev += "{0}@{1:N0}s:{2:+0.0;-0.0}sd" -f $e.type, ($te - $t0), (($am - $bm) / [math]::Max(0.1, $bs))
    }
  }

  [pscustomobject]@{
    File      = [IO.Path]::GetFileNameWithoutExtension($path)
    Length_s  = [math]::Round($dur)
    Avg_mV    = [math]::Round($avg)
    Noise_mV  = [math]::Round($noise, 1)
    Glitch_pct = [math]::Round(100 * $bad / [math]::Max(1, $n - 1), 1)
    Wave_p2p_mV = [math]::Round($p2p)
    Wave_sd_mV = [math]::Round($sd, 1)
    Period_s  = if ($bestLag) { [math]::Round($bestLag / 10, 1) } else { "-" }
    Regularity = [math]::Round($bestR, 2)
    Events    = ($ev -join " ")
  }
}

$files = foreach ($p in $Paths) { Get-ChildItem $p -File }
$files | ForEach-Object { Analyze $_.FullName } | Format-List
"Regularity: 0 = no repeating rhythm, 1 = perfectly regular. Real plant signals are usually irregular; a big, very regular wave points to a contact artefact."
"Event change: about +-2 sd or more after a touch is worth a second look; below 1 sd is noise."

# Plant Music

An instrument that turns electrical signals from living plants into music that follows the data, so plants at different life stages sound different.

## Hardware

| Item | Details |
|---|---|
| Microcontroller | ESP32 DevKit V1 (ESP-WROOM-32), USB-C, COM3. FQBN `esp32:esp32:esp32` |
| Electrode cable | BioAmp Cable v3: Black = IN-, Red = IN+, Yellow = REF |
| Electrodes | Gel snap electrodes |
| Laptop | Chrome or Edge, for the browser instrument |
| Phone | iPhone with GarageBand (optional, Bluetooth MIDI sketches) |

The Muscle BioAmp Blip is not used for plants: its 72 to 720 Hz bandpass removes the slow plant signal.

## Wiring (two plants, direct to ESP32, on the soldered perfboard)

| ESP32 pin | Lead | Electrode |
|---|---|---|
| D34 | Plant 1 red (IN+) | Underside of a leaf, plant 1 |
| D25 | Plant 1 yellow (REF) | Wet soil, plant 1. D25 outputs ~1.1 V (`dacWrite(25, 85)`) |
| D35 | Plant 2 red (IN+) | Underside of a leaf, plant 2 |
| D26 | Plant 2 yellow (REF) | Wet soil, plant 2. D26 outputs ~1.1 V |
| none | Both black leads (IN-) | Not used (a D4 capacitive touch sensor was tried and removed, see below) |

Optional 1.3" I2C OLED (SH1106), set `USE_OLED 1` in Plant_Stream: GND to GND, VCC to 3V3, SCL to D22, SDA to D21.

Check with a multimeter that D34/D35 and D25/D26 (neighbouring pins) are not bridged. First check after soldering (14 Nov 2026): plant 2 1193 mV and hum 80, perfect; plant 1 353 mV, its yellow/D25 path needed checking.

No resistors. Contact check: Pin_mV should settle near 1100 mV (800 to 1300 is fine). A steady 142 mV means no connection.

## Safety

1. Electrodes on a human: laptop on battery, charger unplugged. Never mains power.
2. A 5V wall adapter is fine for plants only, and adds 50 Hz hum.
3. Never put more than 3.3V into an ESP32 analog pin.

## Main instrument: Plant drone in the browser

The ESP32 runs `Plant_Stream` (raw voltage over USB, 50 Hz). Chrome reads it with Web Serial and plays it with Web Audio: real sine oscillators on the harmonic series of a root note.

1. Upload the sensor sketch once: `.\build.ps1 Plant_Stream -Upload`
2. Start the page server: `.\serve.ps1`
3. Open http://localhost:8000 in Chrome or Edge.
4. Click Connect ESP32, pick COM3. Wait for "Contact OK" and a settled signal (1 to 2 minutes).
5. Click Start sound. Pick Harmonic ladder or Smooth glide.
6. Fill in plant, stage, run. Start recording. Keys T, W, L, M mark touch, water, light, other.
7. Stop recording saves a CSV to Downloads. Move it into `data/`.

Close the Arduino Serial Monitor first: only one program can use COM3. Demo signal lets you try the page without the board.

Modes (no beats):
1. Scale melody (default): the plant level picks a note from the chosen scale over two octaves. Notes step (60 ms move, re-attacked), they do not slide. A soft root and fifth drone sits underneath. Activity sets brightness.
2. Harmonic ladder: the plant level slides through the harmonic series of the root.
Beats (checkbox, on by default, with Tempo and Beats volume): a drums-only layer from `instrument/groove.js` under the melody (kick, clap, offbeat open hats; extra hats when the plant is active). No bass or chords, so nothing fights the plant's melody. Silent without plant data. When the plant is touched the beat instantly goes muffled (low-pass to 450 Hz in about 50 ms) and half-time, so the melody's octave jump stands out; on release it opens back up over one beat with a crash. Smooth glide (siren) and the full House groove were removed from the menu on 13 Nov 2026.

Touching the plant (automatic, body hum), or the T key / T touch button:
1. Tap: the melody jumps up an octave within 50 ms, stays about 1 s, then steps back down.
2. Hold: jumps an octave, then climbs up to 3 more scale notes while held (about +21 semitones after 3 s). Release: stays about 1 s, then back down.

How the plant feels a touch: Plant_Stream also sends `Hum_mV`, the 50 Hz swing on D34 inside each 20 ms. A human body picks up mains hum, so a hand on the plant raises it. Nothing is driven into the plant. Measured 14 Nov 2026 (`data/20261114_*hum*.csv`): resting about 240 to 450 mV, firm touch 560 to 745 mV, light touch only about 1.3x. The page smooths it over about 60 ms, takes the quieter quarter of the last 5 s as resting, and counts a touch when it is 150 mV and (Touch sensitivity - 1) x resting above that for 3 readings in a row (default 1.35x). Reaction about 100 ms. Replay of the recordings: no false touches in 30 s idle, firm touches caught. A hand moving close to the plant can raise the hum a little too: raise Touch sensitivity if it triggers without a touch. Touch firmly (pinch the leaf near the electrode) for the clearest response.

Big finding, 14 Nov 2026: with the yellow soil lead loose, D34 swung across the whole 0 to 3 V range every 20 ms (Hum_mV 3013 the whole time). Averaging that out of step with 50 Hz makes slow fake waves, which most likely explains the large regular "plant waves" in earlier recordings. Re-seating the soil lead dropped the hum to about 250 mV and the plant voltage settled at a steady 1101 to 1104 mV. Check the soil lead (and run on battery) before every recording.

Earlier: an ESP32 capacitive touch sensor on D4 (black lead on the stem) was tried on 13 Nov 2026 and removed. With the plant connected the touch count dropped from about 1900 to about 230 and touches made no visible step (with and without the soil lead), while its pulses added about 10 jumps per second to the D34 signal. Recordings: `data/*touch_test*.csv`. The page still understands `Touch:` lines if a separate touch or distance sensor is added later. In the no-soil-lead test, touch count and D34 voltage rose and fell together every 6 to 7 s, which points to outside interference rather than plant activity.

Other keys: W water raises the key a whole step for 30 s, L light switches Scale melody to major pentatonic for 30 s.

Automatic, no settings needed:
1. Glitch guard: pin below 300 mV or a jump over 50 mV per sample holds the sound, fades it to a hum and shades the plot. Afterwards the new level is joined onto the old one. Glitch samples are marked "glitch" in the CSV and left out of auto range.
2. Activity is measured against this plant's own last 60 s (90th percentile), so it no longer sits at 100%.
3. Brightness: activity opens a low-pass filter. Calm plant = dark and soft, active plant = bright.
4. Response: a 2 s change more than 6 robust deviations above the plant's normal 2 s changes, and over 3x the median, logs a "response" event and plays a bell (or crash and fill in House groove). At most one per 20 s, only after 60 s of learning. Can be switched off.

Defaults were set from a real 60 s recording (median rate 1.5 mV/s, p90 3.8 mV/s, swing about 26 mV): Activity full 8 mV/s, minimum range 10 mV with auto range on.

## Plant studio: recording to house track (Ableton)

Open http://localhost:8000/studio.html (with `.\serve.ps1` running), drop a CSV from `data/`, pick tempo, key and scale, download the files.

| File | What the plant controls |
|---|---|
| `plant_bass.mid` | Offbeat 8th bass. Plant level picks the scale note. Velocity follows slow drift (map velocity to filter) |
| `plant_chords.mid` | Chord stabs where the plant jumps clearly above its own normal movement, or on marked events |
| `plant_hats.mid` | Hi-hats. Busier when the plant is more active (ranked against the same recording) |
| `plant_pad.wav` | Real-time pad that glides with the bass note and swells with the plant |
| `plant_sample.wav` | The plant's own waveform sped up 200 to 800x. No synthesis |

Contact glitches (pin below 300 mV, jumps over 50 mV per sample) are skipped: no notes, and the level after a dropout is joined back on. Nothing is random: the same CSV always gives the same files. Ableton steps are listed on the page.

## Sketches

| Sketch | What it does |
|---|---|
| `Plant_Stream` | Two-plant sensor for the browser instrument. Prints `Raw_mV:1103.2,Hum_mV:250.0,Raw2_mV:1193.0,Hum2_mV:80.0` 50 times a second (average and 50 Hz swing over each 20 ms window, per plant). OLED drawn on core 0. |
| `Plant_Direct` | Reads D34 with oversampling and slow drift removal. `PLOT_MODE 0` prints Pin_mV for wiring checks, `PLOT_MODE 1` plots Plant_mV with guide lines. 25 points per second. |
| `Plant_Melody` | Bluetooth LE MIDI instrument "Plant Melody". Self-calibrating range, plant level picks the scale note (with hysteresis), rate of change sets velocity, drone with mod wheel (CC1) following activity. Needs the Huge APP partition scheme. |
| `Plant_Drone` | Bluetooth LE MIDI "Plant Drone". One continuous drone. `DRONE_MODE 0` GLIDE: plant level bends the pitch smoothly. `DRONE_MODE 1` LADDER: plant level climbs the harmonic series of the root, steps overlap, pitch bend tunes each harmonic and wobbles with the signal. Activity drives mod wheel (CC1) and expression (CC11). Prints Raw_mV, Level, Activity, Bend, Harmonic every sample. |

## Build and upload

Uses the arduino-cli bundled with Arduino IDE 2 and ESP32 core 3.3.12. `build.ps1` picks the Huge APP partition automatically for Bluetooth sketches.

```bash
.\build.ps1 Plant_Drone
```

```bash
.\build.ps1 Plant_Drone -Upload -Monitor
```

Close the Arduino IDE Serial Monitor before uploading, or COM3 will be busy. If upload stalls at "Connecting...", hold the BOOT button on the ESP32 until it starts.

## GarageBand (optional, Bluetooth sketches only)

GarageBand > pick an instrument > Settings > Advanced > Bluetooth MIDI Devices > connect "Plant Melody" or "Plant Drone".

## Two plants (page)

Plant 2 (`instrument/plant2.js`) has its own signal processing, auto range, touch detection and voice: a soft counter-melody one octave below plant 1, same root and scale, so the plants harmonise. Plant 2 volume slider. Purple line on the graph, its own tile, and `raw2_mv, level2, hum2` columns in the CSV. Touching plant 2 jumps its voice up an octave (measured 60 ms), holds about 1 s after release, then comes back; the beat muffles while either plant is touched.
